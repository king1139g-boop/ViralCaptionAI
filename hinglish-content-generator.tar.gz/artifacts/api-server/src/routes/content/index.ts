import { Router, type IRouter, type Request } from "express";
import { openrouter } from "@workspace/integrations-openrouter-ai";
import { GenerateContentBody, GenerateContentResponse } from "@workspace/api-zod";

const router: IRouter = Router();

const users: Record<string, number> = {};
const proUsers: string[] = [];

router.post("/content/generate", async (req, res) => {
  const ip = (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress;

  if (!proUsers.includes(ip as string)) {
    if (!users[ip as string]) users[ip as string] = 0;
    users[ip as string]++;

    if (users[ip as string] > 2) {
      res.status(429).json({ error: "Daily free limit finished. Buy plan ₹99." });
      return;
    }
  }

  let parsed;
  try {
    parsed = GenerateContentBody.parse(req.body);
  } catch (err: unknown) {
    if (err && typeof err === "object" && "issues" in err) {
      res.status(400).json({ error: "Invalid request body" });
      return;
    }
    throw err;
  }

  const { topic, platform, tone } = parsed;

  const prompt = `You are a creative Hinglish social media content writer. Generate engaging content for ${platform} about "${topic}" in a ${tone} tone.

Write your response in Hinglish (a fun mix of Hindi and English, like Indians naturally speak on social media).

Respond ONLY with valid JSON in this exact format:
{
  "caption": "The main post caption in Hinglish (2-4 sentences, engaging and natural)",
  "hashtags": ["hashtag1", "hashtag2", "hashtag3", "hashtag4", "hashtag5"],
  "callToAction": "A short call to action in Hinglish"
}

Rules:
- Caption must be in Hinglish - mix Hindi words naturally with English
- Hashtags should be relevant, some in English, some in Hinglish, without the # symbol
- Tailor the style for ${platform}
- Keep the ${tone} tone throughout
- Do not include any text outside the JSON`;

  try {
    const completion = await openrouter.chat.completions.create({
      model: "mistralai/mistral-small-2603",
      max_tokens: 8192,
      messages: [{ role: "user", content: prompt }],
    });

    const content = completion.choices[0]?.message?.content ?? "";

    let parsed_json;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (!jsonMatch) throw new Error("No JSON found in response");
      parsed_json = JSON.parse(jsonMatch[0]);
    } catch {
      req.log.error({ content }, "Failed to parse AI response as JSON");
      res.status(500).json({ error: "Failed to parse AI response" });
      return;
    }

    const result = GenerateContentResponse.parse(parsed_json);
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Error generating content");
    res.status(500).json({ error: "Failed to generate content" });
  }
});

router.post("/admin/pro-users", (req, res) => {
  const adminKey = process.env.ADMIN_KEY;
  if (!adminKey || req.headers["x-admin-key"] !== adminKey) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const { ip } = req.body as { ip?: string };
  if (!ip) {
    res.status(400).json({ error: "ip is required" });
    return;
  }

  if (!proUsers.includes(ip)) {
    proUsers.push(ip);
    delete users[ip];
  }

  res.json({ success: true, proUsers });
});

export default router;
