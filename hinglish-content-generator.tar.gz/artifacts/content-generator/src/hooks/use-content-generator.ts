import { useGenerateContent } from "@workspace/api-client-react";
import type { GenerateContentRequest } from "@workspace/api-client-react/src/generated/api.schemas";

export function useContentGenerator() {
  return useGenerateContent();
}
