import { Instagram, Twitter, Facebook, Youtube, Linkedin, Globe } from "lucide-react";
import { cn } from "@/lib/utils";

type Platform = "instagram" | "twitter" | "facebook" | "youtube" | "linkedin" | string;

export function PlatformIcon({ platform, className }: { platform: Platform; className?: string }) {
  switch (platform.toLowerCase()) {
    case "instagram":
      return (
        <div className={cn("relative flex items-center justify-center overflow-hidden rounded-md bg-gradient-to-tr from-[#fd5949] to-[#d6249f]", className)}>
           <Instagram className="w-full h-full p-1.5 text-white" />
        </div>
      );
    case "twitter":
      return (
        <div className={cn("flex items-center justify-center rounded-md bg-[#1DA1F2]", className)}>
          <Twitter className="w-full h-full p-1.5 text-white fill-current" />
        </div>
      );
    case "facebook":
      return (
        <div className={cn("flex items-center justify-center rounded-md bg-[#1877F2]", className)}>
          <Facebook className="w-full h-full p-1.5 text-white fill-current" />
        </div>
      );
    case "youtube":
      return (
        <div className={cn("flex items-center justify-center rounded-md bg-[#FF0000]", className)}>
          <Youtube className="w-full h-full p-1.5 text-white" />
        </div>
      );
    case "linkedin":
      return (
        <div className={cn("flex items-center justify-center rounded-md bg-[#0A66C2]", className)}>
          <Linkedin className="w-full h-full p-1.5 text-white fill-current" />
        </div>
      );
    default:
      return (
        <div className={cn("flex items-center justify-center rounded-md bg-muted", className)}>
          <Globe className="w-full h-full p-1.5 text-muted-foreground" />
        </div>
      );
  }
}
