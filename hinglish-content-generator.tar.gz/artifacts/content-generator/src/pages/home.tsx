import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Copy, CheckCircle2, AlertCircle, RefreshCw, Wand2, ArrowRight, Sparkles, Lock, Zap } from "lucide-react";
import { Header } from "@/components/layout/Header";
import { useContentGenerator } from "@/hooks/use-content-generator";
import { PlatformIcon } from "@/components/ui/platform-icon";
import { cn } from "@/lib/utils";
import type { GenerateContentRequestPlatform, GenerateContentRequestTone } from "@workspace/api-client-react/src/generated/api.schemas";

const PLATFORMS: { id: GenerateContentRequestPlatform; label: string }[] = [
  { id: "instagram", label: "Instagram" },
  { id: "twitter", label: "Twitter" },
  { id: "linkedin", label: "LinkedIn" },
  { id: "facebook", label: "Facebook" },
  { id: "youtube", label: "YouTube" },
];

const TONES: { id: GenerateContentRequestTone; label: string; emoji: string; desc: string }[] = [
  { id: "casual", label: "Casual & Chill", emoji: "😎", desc: "Relaxed, friendly vibe" },
  { id: "funny", label: "Funny & Witty", emoji: "😂", desc: "Humorous and engaging" },
  { id: "professional", label: "Professional", emoji: "👔", desc: "Clean, business-appropriate" },
  { id: "motivational", label: "Motivational", emoji: "🔥", desc: "Inspiring and uplifting" },
  { id: "educational", label: "Educational", emoji: "📚", desc: "Informative and clear" },
  { id: "romantic", label: "Romantic", emoji: "💖", desc: "Sweet and affectionate" },
];

export default function Home() {
  const [topic, setTopic] = useState("");
  const [platform, setPlatform] = useState<GenerateContentRequestPlatform>("instagram");
  const [tone, setTone] = useState<GenerateContentRequestTone>("casual");
  const [copied, setCopied] = useState(false);
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { mutate: generateContent, data: result, isPending, isError, error, reset } = useContentGenerator();

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [topic]);

  const handleGenerate = () => {
    if (!topic.trim()) return;
    generateContent({
      data: {
        topic: topic.trim(),
        platform,
        tone,
      }
    });
  };

  const handleCopy = () => {
    if (!result) return;
    const textToCopy = `${result.caption}\n\n${result.callToAction}\n\n${result.hashtags.join(" ")}`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const resetForm = () => {
    setTopic("");
    reset();
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Background Image Layer */}
      <div className="absolute inset-0 z-[-1] opacity-40 mix-blend-screen pointer-events-none">
        <img 
          src={`${import.meta.env.BASE_URL}images/hero-bg.png`} 
          alt="Abstract Background" 
          className="w-full h-full object-cover"
        />
      </div>

      <Header />

      <main className="flex-1 pt-28 pb-20 px-4 sm:px-6 lg:px-8 w-full max-w-7xl mx-auto flex flex-col lg:flex-row gap-8 lg:gap-12 items-start">
        
        {/* Left Column: Form */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="w-full lg:w-[45%] flex flex-col gap-8 sticky top-28"
        >
          <div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-extrabold leading-[1.1] mb-4">
              Create viral <span className="text-gradient">Hinglish</span> content in seconds.
            </h1>
            <p className="text-lg text-muted-foreground">
              Drop your topic below, pick a vibe, and let our AI craft the perfect caption and hashtags for your next post.
            </p>
          </div>

          <div className="glass-panel p-6 sm:p-8 rounded-3xl flex flex-col gap-8 relative overflow-hidden">
            {/* Ambient glow behind form */}
            <div className="absolute -top-24 -right-24 w-48 h-48 bg-primary/20 blur-[80px] rounded-full pointer-events-none" />
            <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-secondary/20 blur-[80px] rounded-full pointer-events-none" />

            {/* Topic Input */}
            <div className="space-y-3 relative z-10">
              <label className="text-sm font-semibold tracking-wide text-foreground/90 uppercase">
                What's the post about?
              </label>
              <div className="relative group">
                <textarea
                  ref={textareaRef}
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="e.g. 5 tips for productivity, or a funny story about traffic in Mumbai..."
                  className="w-full min-h-[120px] resize-none bg-black/20 border-2 border-white/10 rounded-2xl p-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/10 transition-all duration-300"
                />
              </div>
            </div>

            {/* Platform Selection */}
            <div className="space-y-3 relative z-10">
              <label className="text-sm font-semibold tracking-wide text-foreground/90 uppercase">
                Select Platform
              </label>
              <div className="grid grid-cols-5 gap-2 sm:gap-3">
                {PLATFORMS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setPlatform(p.id)}
                    className={cn(
                      "flex flex-col items-center justify-center gap-2 p-3 rounded-2xl border transition-all duration-200 group",
                      platform === p.id 
                        ? "bg-white/10 border-primary/50 shadow-[0_0_15px_rgba(236,72,153,0.15)]" 
                        : "bg-black/20 border-white/5 hover:bg-white/5 hover:border-white/20"
                    )}
                  >
                    <PlatformIcon platform={p.id} className={cn("w-8 h-8 sm:w-10 sm:h-10 transition-transform duration-300", platform === p.id ? "scale-110" : "group-hover:scale-110")} />
                    <span className={cn("text-[10px] sm:text-xs font-medium transition-colors", platform === p.id ? "text-white" : "text-muted-foreground")}>
                      {p.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Tone Selection */}
            <div className="space-y-3 relative z-10">
              <label className="text-sm font-semibold tracking-wide text-foreground/90 uppercase">
                Choose Tone
              </label>
              <div className="grid grid-cols-2 gap-3">
                {TONES.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTone(t.id)}
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-xl border text-left transition-all duration-200",
                      tone === t.id 
                        ? "bg-secondary/20 border-secondary/50 shadow-[0_0_15px_rgba(139,92,246,0.15)]" 
                        : "bg-black/20 border-white/5 hover:bg-white/5 hover:border-white/20"
                    )}
                  >
                    <span className="text-2xl">{t.emoji}</span>
                    <div className="flex flex-col">
                      <span className={cn("text-sm font-semibold", tone === t.id ? "text-white" : "text-foreground/80")}>{t.label}</span>
                      <span className="text-[10px] text-muted-foreground line-clamp-1">{t.desc}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <button
              onClick={handleGenerate}
              disabled={!topic.trim() || isPending}
              className={cn(
                "relative z-10 w-full py-4 px-6 rounded-2xl font-bold text-lg flex items-center justify-center gap-3 overflow-hidden transition-all duration-300",
                !topic.trim() || isPending 
                  ? "bg-muted text-muted-foreground cursor-not-allowed" 
                  : "bg-gradient-to-r from-primary via-secondary to-accent text-white shadow-[0_0_30px_rgba(236,72,153,0.3)] hover:shadow-[0_0_40px_rgba(236,72,153,0.5)] hover:-translate-y-1"
              )}
            >
              {isPending ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  Generating Magic...
                </>
              ) : (
                <>
                  <Wand2 className="w-5 h-5" />
                  Generate Content
                </>
              )}
              
              {/* Shine effect on hover */}
              {!isPending && topic.trim() && (
                 <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent hover:animate-[shimmer_1.5s_infinite]" />
              )}
            </button>
          </div>
        </motion.div>

        {/* Right Column: Results */}
        <div className="w-full lg:w-[55%] lg:min-h-[600px] flex flex-col justify-center">
          <AnimatePresence mode="wait">
            {!result && !isPending && !isError && (
              <motion.div 
                key="empty"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4 }}
                className="flex flex-col items-center justify-center text-center p-12 h-full glass-panel rounded-3xl border-dashed border-white/20"
              >
                <div className="w-24 h-24 mb-6 rounded-full bg-gradient-to-tr from-primary/20 to-secondary/20 flex items-center justify-center border border-white/10">
                  <Send className="w-10 h-10 text-primary opacity-50" />
                </div>
                <h3 className="text-2xl font-display font-bold text-foreground mb-2">Ready to create?</h3>
                <p className="text-muted-foreground max-w-sm">
                  Fill out the form on the left and hit generate to see your custom Hinglish content appear right here.
                </p>
              </motion.div>
            )}

            {isPending && (
              <motion.div 
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center text-center p-12 h-full glass-panel rounded-3xl"
              >
                <div className="relative w-24 h-24 mb-8">
                  <div className="absolute inset-0 rounded-full border-t-2 border-primary animate-spin" />
                  <div className="absolute inset-2 rounded-full border-r-2 border-secondary animate-[spin_1.5s_linear_infinite]" />
                  <div className="absolute inset-4 rounded-full border-b-2 border-accent animate-[spin_2s_linear_infinite]" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-primary animate-pulse" />
                  </div>
                </div>
                <h3 className="text-xl font-display font-bold text-foreground animate-pulse">
                  Crafting the perfect vibe...
                </h3>
                <p className="text-muted-foreground mt-2">Our AI is mixing Hindi, English, and pure creativity.</p>
              </motion.div>
            )}

            {isError && (() => {
              const isRateLimit = error?.message?.toLowerCase().includes("limit") || error?.message?.toLowerCase().includes("plan");
              return isRateLimit ? (
                <motion.div
                  key="rate-limit"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="flex flex-col items-center justify-center text-center p-12 h-full bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-3xl backdrop-blur-xl"
                >
                  <div className="w-20 h-20 rounded-full bg-yellow-500/20 flex items-center justify-center mb-5">
                    <Lock className="w-9 h-9 text-yellow-400" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">Free Limit Khatam! 🚫</h3>
                  <p className="text-muted-foreground mb-2 max-w-xs">
                    Aapke 2 free requests use ho gaye.
                  </p>
                  <div className="flex gap-3 mb-4 w-full max-w-xs">
                    <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-4 py-4 flex flex-col items-center">
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Basic</p>
                      <p className="text-2xl font-bold text-yellow-400">₹99<span className="text-xs font-normal text-muted-foreground">/mo</span></p>
                      <p className="text-xs text-muted-foreground mt-1">Unlimited posts</p>
                      <a href="upi://pay?pa=9587655914@ybl&pn=Goutam&am=99&cu=INR" className="mt-3 w-full">
                        <button className="w-full py-2 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-400 hover:to-orange-400 rounded-lg font-bold text-black text-sm transition-all flex items-center justify-center gap-1">
                          <Zap className="w-3 h-3" /> Buy
                        </button>
                      </a>
                    </div>
                    <div className="flex-1 bg-purple-500/10 border border-purple-400/30 rounded-2xl px-4 py-4 flex flex-col items-center relative">
                      <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-purple-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">PRO</span>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Pro</p>
                      <p className="text-2xl font-bold text-purple-400">₹199<span className="text-xs font-normal text-muted-foreground">/mo</span></p>
                      <p className="text-xs text-muted-foreground mt-1">Priority + extras</p>
                      <a href="upi://pay?pa=9587655914@ybl&pn=Goutam&am=199&cu=INR" className="mt-3 w-full">
                        <button className="w-full py-2.5 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 rounded-lg font-bold text-white text-xl transition-all flex items-center justify-center gap-1 px-5">
                          <Zap className="w-4 h-4" /> Buy Pro ₹199
                        </button>
                      </a>
                    </div>
                  </div>
                  <div className="w-full max-w-xs bg-white/5 border border-white/10 rounded-2xl px-4 py-3 text-left space-y-1">
                    <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider mb-2">Payment Info</p>
                    <p className="text-sm text-foreground">🏦 UPI ID: <span className="font-mono font-bold text-yellow-400">9587655914@ybl</span></p>
                    <p className="text-sm text-foreground">💰 Amount: <span className="font-bold">₹99</span></p>
                    <p className="text-sm text-muted-foreground">📲 Screenshot bhejo WhatsApp pe: <a href="https://wa.me/919587655914" target="_blank" rel="noreferrer" className="text-green-400 font-bold underline">9587655914</a></p>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="error"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="flex flex-col items-center justify-center text-center p-12 h-full bg-destructive/10 border border-destructive/20 rounded-3xl backdrop-blur-xl"
                >
                  <AlertCircle className="w-16 h-16 text-destructive mb-4" />
                  <h3 className="text-2xl font-display font-bold text-foreground mb-2">Oops! Something went wrong</h3>
                  <p className="text-muted-foreground mb-6 max-w-md">
                    {error?.message || "We couldn't generate the content right now. Please try again."}
                  </p>
                  <button
                    onClick={handleGenerate}
                    className="px-6 py-3 bg-white/10 hover:bg-white/20 rounded-xl font-semibold transition-colors flex items-center gap-2"
                  >
                    <RefreshCw className="w-4 h-4" /> Try Again
                  </button>
                </motion.div>
              );
            })()}

            {result && !isPending && (
              <motion.div 
                key="result"
                initial={{ opacity: 0, y: 30, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                className="glass-panel p-6 sm:p-8 md:p-10 rounded-3xl flex flex-col h-full relative"
              >
                {/* Result Header */}
                <div className="flex items-center justify-between mb-8 pb-6 border-b border-white/10">
                  <div className="flex items-center gap-3">
                    <PlatformIcon platform={platform} className="w-10 h-10 shadow-lg" />
                    <div>
                      <h3 className="font-bold text-lg capitalize">{platform} Post</h3>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        {TONES.find(t => t.id === tone)?.emoji} {TONES.find(t => t.id === tone)?.label} Tone
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={handleCopy}
                      className={cn(
                        "flex items-center gap-2 px-4 py-2 rounded-xl font-medium text-sm transition-all duration-300",
                        copied 
                          ? "bg-green-500/20 text-green-400 border border-green-500/30" 
                          : "bg-white/5 hover:bg-white/10 text-foreground border border-white/10 hover:border-white/20"
                      )}
                    >
                      {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      {copied ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>

                {/* Content Area */}
                <div className="flex-1 overflow-y-auto pr-2 pb-6 space-y-8">
                  {/* Caption */}
                  <div>
                    <h4 className="text-xs font-bold tracking-widest text-primary uppercase mb-3 flex items-center gap-2">
                      <Sparkles className="w-3 h-3" /> Caption
                    </h4>
                    <p className="text-lg sm:text-xl text-foreground/90 leading-relaxed whitespace-pre-wrap font-medium">
                      {result.caption}
                    </p>
                  </div>

                  {/* Call to Action */}
                  <div className="bg-primary/10 border border-primary/20 rounded-2xl p-5 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-primary to-secondary" />
                    <h4 className="text-xs font-bold tracking-widest text-secondary uppercase mb-2">
                      Call to Action
                    </h4>
                    <p className="text-foreground font-semibold flex items-start gap-2">
                      <ArrowRight className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      {result.callToAction}
                    </p>
                  </div>

                  {/* Hashtags */}
                  <div>
                    <h4 className="text-xs font-bold tracking-widest text-accent uppercase mb-3">
                      Hashtags
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {result.hashtags.map((tag, i) => (
                        <span 
                          key={i} 
                          className="px-3 py-1.5 rounded-full bg-black/30 border border-white/10 text-sm font-medium text-blue-300 hover:bg-white/10 hover:border-blue-400/50 transition-colors cursor-default"
                        >
                          {tag.startsWith('#') ? tag : `#${tag}`}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Create Another Button */}
                <div className="pt-6 border-t border-white/10 mt-auto">
                  <button 
                    onClick={resetForm}
                    className="w-full py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 font-semibold text-foreground transition-all flex items-center justify-center gap-2 group"
                  >
                    <RefreshCw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" />
                    Create Another Post
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
