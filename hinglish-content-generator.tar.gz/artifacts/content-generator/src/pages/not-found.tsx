import { Link } from "wouter";
import { AlertCircle, Home } from "lucide-react";
import { motion } from "framer-motion";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4 relative overflow-hidden">
      {/* Ambient background */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/30 blur-[100px] rounded-full" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/30 blur-[100px] rounded-full" />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-panel max-w-md w-full p-8 rounded-3xl text-center relative z-10"
      >
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 rounded-2xl bg-destructive/10 flex items-center justify-center border border-destructive/20 shadow-[0_0_30px_rgba(220,38,38,0.2)]">
            <AlertCircle className="h-10 w-10 text-destructive" />
          </div>
        </div>
        
        <h1 className="text-4xl font-display font-bold text-foreground mb-2">404</h1>
        <h2 className="text-xl font-semibold text-foreground/80 mb-4">Page Not Found</h2>
        
        <p className="text-muted-foreground mb-8">
          The vibe you're looking for doesn't exist. Let's get you back to creating awesome content.
        </p>
        
        <Link 
          href="/" 
          className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-foreground text-background font-bold hover:bg-foreground/90 transition-all hover:-translate-y-1 hover:shadow-lg w-full"
        >
          <Home className="w-5 h-5" />
          Back to Generator
        </Link>
      </motion.div>
    </div>
  );
}
