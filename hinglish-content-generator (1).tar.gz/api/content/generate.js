const users = {};
const proUsers = [];

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const ip =
    (req.headers["x-forwarded-for"] || "").split(",")[0].trim() ||
    req.socket?.remoteAddress ||
    "unknown";

  if (!proUsers.includes(ip)) {
    if (!users[ip]) users[ip] = 0;
    users[ip]++;

    if (users[ip] > 2) {
      return res
        .status(429)
        .json({ error: "Daily free limit finished. Buy plan \u20b999." });
    }
  }

  const { topic, platform, tone } = req.body;

  if (!topic || !platform || !tone) {
    return res.status(400).json({ error: "topic, platform and tone are required" });
  }

  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "OPENROUTER_API_KEY not set on Vercel" });
  }

  const prompt = `You are a creative Hinglish social media content writer. Generate engaging content for ${platform} about "${topic}" in a ${tone} tone.

Write your response in Hinglish (a fun mix of Hindi and English, like Indians naturally speak on social media).

Respond ONLY with valid JSON in this exact format:
{
  "caption": "The main post caption in Hinglish (2-4 sentences, engaging and natural)",
  "hashtags": ["hashtag1", "hashtag2", "hashtag3", "hashtag4", "hashtag5"],
  "callToAction": "A short call to action in Hinglish"
}

Rules:
- Caption must be in Hinglish - mix Hindi words naturally with English
- Hashtags should be relevant, some in English, some in Hinglish, without the # symbol
- Tailor the style for ${platform}
- Keep the ${tone} tone throughout
- Do not include any text outside the JSON`;

  try {
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "mistralai/mistral-small-2603",
        max_tokens: 8192,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content ?? "";

    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return res.status(500).json({ error: "Failed to parse AI response" });
    }

    const result = JSON.parse(jsonMatch[0]);
    return res.json(result);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Failed to generate content" });
  }
}
